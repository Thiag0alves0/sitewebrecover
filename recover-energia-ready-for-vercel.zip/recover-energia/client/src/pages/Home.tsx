import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, CheckCircle, Zap, TrendingDown, Leaf, Phone, Mail, MapPin, Star, ArrowRight, Shield, Clock, Users, Lightbulb, MessageCircle, ChevronDown } from "lucide-react";
import { useLocation } from "wouter";
import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function Home() {
  const { user, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    energyBillAmount: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeTab, setActiveTab] = useState(0);

  const createLeadMutation = trpc.leads.create.useMutation({
    onSuccess: () => {
      setLocation("/thank-you");
      setFormData({ name: "", phone: "", email: "", energyBillAmount: "" });
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao enviar formulário");
    },
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await createLeadMutation.mutateAsync(formData);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (authLoading) {
    return <div className="flex items-center justify-center min-h-screen"><Loader2 className="animate-spin" /></div>;
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/80 backdrop-blur-xl border-b border-border">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-600 to-green-500 flex items-center justify-center">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold gradient-text">Recover Energy</span>
          </div>
          <div className="hidden md:flex gap-8">
            <a href="#como-funciona" className="text-sm font-medium hover:text-accent transition-smooth">Como funciona</a>
            <a href="#beneficios" className="text-sm font-medium hover:text-accent transition-smooth">Benefícios</a>
            <a href="#testemunhos" className="text-sm font-medium hover:text-accent transition-smooth">Testemunhos</a>
            <a href="#faq" className="text-sm font-medium hover:text-accent transition-smooth">FAQ</a>
          </div>
          {user && user.role === "admin" && (
            <Button onClick={() => setLocation("/dashboard")} className="bg-accent hover:bg-accent/90 text-accent-foreground">
              Dashboard
            </Button>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative py-24 px-4 overflow-hidden">
        {/* Background gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-white to-green-50 dark:from-blue-950/20 dark:via-background dark:to-green-950/20 -z-10" />
        
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div className="animate-fade-in-up">
              {/* Social proof badge */}
              <div className="mb-8 inline-flex items-center gap-2 px-4 py-2 rounded-full bg-green-100/50 dark:bg-green-900/30 border border-green-200 dark:border-green-800">
                <Users className="w-4 h-4 text-green-600 dark:text-green-400" />
                <span className="text-sm font-medium text-green-700 dark:text-green-300">+2000 empresas já economizaram</span>
              </div>

              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
                Reduza sua conta de energia em até <span className="gradient-text">30%</span>
              </h1>
              
              <p className="text-lg md:text-xl text-muted-foreground mb-8 leading-relaxed">
                Sem investimento inicial, sem obras, sem burocracia. Soluções inteligentes com análise estratégica de mercado para sua empresa economizar desde o primeiro mês.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 mb-12">
                <Button 
                  size="lg"
                  className="bg-accent hover:bg-accent/90 text-accent-foreground font-bold rounded-lg group shadow-soft hover:shadow-lg transition-smooth btn-hover"
                  onClick={() => {
                    const element = document.getElementById('simulacao');
                    element?.scrollIntoView({ behavior: 'smooth' });
                  }}
                >
                  Simular economia agora
                  <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              <Button 
                size="lg"
                variant="outline"
                className="border-2 border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/20 font-bold rounded-lg transition-smooth btn-hover"
                  onClick={() => window.open('https://wa.me/5585981809403?text=Olá, gostaria de saber mais sobre a Recover Energy', '_blank')}
                >
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Falar no WhatsApp
                </Button>
              </div>

              {/* Trust elements */}
              <div className="flex gap-8 text-sm">
                <div className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-green-600 dark:text-green-400" />
                  <span className="text-muted-foreground">Sem dados compartilhados</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                  <span className="text-muted-foreground">Resposta rápida e imediata.</span>
                </div>
              </div>
            </div>

            {/* Hero image */}
            <div className="relative animate-slide-in-right">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-400/20 to-green-400/20 rounded-2xl blur-3xl" />
              <img 
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663566836400/dkdSXBiv7qbm9PGkpxADaX/recover-logo_a9e4e86e.png" 
                alt="Recover Energy" 
                className="relative w-full h-auto rounded-2xl shadow-soft hover:shadow-lg transition-smooth" 
              />
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 px-4 bg-card/50 border-y border-border">
        <div className="max-w-7xl mx-auto grid md:grid-cols-4 gap-8">
          {[
            { number: "2000+", label: "Empresas atendidas" },
            { number: "30%", label: "Economia média" },
            { number: "6+", label: "Anos de experiência" },
            { number: "0", label: "Investimento inicial" },
          ].map((stat, idx) => (
            <div key={idx} className="text-center">
              <div className="text-3xl md:text-4xl font-bold gradient-text mb-2">{stat.number}</div>
              <div className="text-muted-foreground">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Sobre Section */}
      <section className="py-24 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="mb-16">
            <img 
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663566836400/dkdSXBiv7qbm9PGkpxADaX/recover-commitment_9d50aa64.png" 
              alt="Nosso Compromisso" 
              className="w-full h-auto rounded-2xl shadow-soft" 
            />
          </div>

          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Por que escolher a Recover Energy?</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Somos uma plataforma comercial especializada em energia por assinatura, focada na redução de custos e na geração de resultados reais para o seu negócio.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              { 
                icon: Lightbulb, 
                title: "Inteligência de Mercado", 
                desc: "Análise estratégica das melhores opções do mercado para sua empresa" 
              },
              { 
                icon: TrendingDown, 
                title: "Redução Garantida", 
                desc: "Até 30% de economia na sua conta de energia sem investimento" 
              },
              { 
                icon: Shield, 
                title: "Parceiros Confiáveis", 
                desc: "Selecionamos apenas os melhores fornecedores do mercado" 
              },
            ].map((item, idx) => {
              const Icon = item.icon;
              return (
                <Card key={idx} className="p-8 glass dark:glass-dark shadow-soft hover:shadow-lg hover:border-accent/50 transition-smooth group card-hover">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-blue-100 to-green-100 dark:from-blue-900/30 dark:to-green-900/30 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <Icon className="w-6 h-6 text-accent" />
                  </div>
                  <h3 className="text-xl font-bold mb-3">{item.title}</h3>
                  <p className="text-muted-foreground">{item.desc}</p>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Como Funciona Section */}
      <section id="como-funciona" className="py-24 px-4 bg-card/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Como Funciona</h2>
            <p className="text-lg text-muted-foreground">Do diagnóstico à economia em 5 passos simples</p>
          </div>

          <div className="mb-16">
            <img 
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663566836400/dkdSXBiv7qbm9PGkpxADaX/recover-process_75f44277.png" 
              alt="Processo" 
              className="w-full h-auto rounded-2xl shadow-soft" 
            />
          </div>

          <div className="grid md:grid-cols-5 gap-4">
            {[
              { step: 1, title: "Diagnóstico", desc: "Análise completa" },
              { step: 2, title: "Proposta", desc: "Solução personalizada" },
              { step: 3, title: "Implementação", desc: "Sem obras" },
              { step: 4, title: "Ativação", desc: "Contrato assinado" },
              { step: 5, title: "Economia", desc: "Comece a economizar" },
            ].map((item, idx) => (
              <div key={idx} className="relative">
                <div className="text-center">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-600 to-green-500 text-white font-bold flex items-center justify-center mx-auto mb-4 text-lg shadow-soft">
                    {item.step}
                  </div>
                  <h4 className="font-bold mb-1">{item.title}</h4>
                  <p className="text-sm text-muted-foreground">{item.desc}</p>
                </div>
                {idx < 4 && (
                  <div className="hidden md:block absolute top-6 left-[60%] w-[40%] h-0.5 bg-gradient-to-r from-blue-600 to-green-500" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefícios Section */}
      <section id="beneficios" className="py-24 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Benefícios para seu negócio</h2>
            <p className="text-lg text-muted-foreground">Vantagens que vão além da economia</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {[
              { icon: TrendingDown, title: "Redução Imediata", desc: "Comece a economizar no primeiro mês" },
              { icon: Leaf, title: "Sustentabilidade", desc: "Contribua para um futuro mais verde" },
              { icon: Zap, title: "Eficiência", desc: "Otimize o consumo da sua empresa" },
              { icon: Shield, title: "Segurança", desc: "Tecnologia confiável e testada" },
              { icon: Clock, title: "Sem Tempo de Espera", desc: "Implementação rápida e sem obras" },
              { icon: Users, title: "Suporte Dedicado", desc: "Atendimento personalizado disponível de segunda a sexta-feira, das 8h às 18h." },
            ].map((item, idx) => {
              const Icon = item.icon;
              return (
                <Card key={idx} className="p-8 glass dark:glass-dark shadow-soft hover:shadow-lg hover:border-accent/50 transition-smooth group card-hover">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-blue-100 to-green-100 dark:from-blue-900/30 dark:to-green-900/30 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                      <Icon className="w-6 h-6 text-accent" />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold mb-2">{item.title}</h3>
                      <p className="text-muted-foreground">{item.desc}</p>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Testemunhos Section */}
      <section id="testemunhos" className="py-24 px-4 bg-card/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">O que nossos clientes dizem</h2>
            <p className="text-lg text-muted-foreground">Histórias reais de economia e sucesso</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              { 
                name: "João Silva", 
                company: "Indústria XYZ",
                quote: "Economizamos após implementarmos a solução da Recover Energy. Sem nenhum investimento!",
                rating: 5
              },
              { 
                name: "Maria Santos", 
                company: "Comércio ABC",
                quote: "Processo simples, rápido e sem burocracia. Recomendo para qualquer empresa que quer reduzir custos.",
                rating: 5
              },
              { 
                name: "Carlos Oliveira", 
                company: "Logística DEF",
                quote: "Melhor decisão que tomei. A equipe foi muito profissional e o resultado superou expectativas.",
                rating: 5
              },
            ].map((testimonial, idx) => (
              <Card key={idx} className="p-8 border-border/50 shadow-soft hover:shadow-lg transition-smooth">
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-muted-foreground mb-6 italic">"{testimonial.quote}"</p>
                <div>
                  <p className="font-bold">{testimonial.name}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.company}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Simulação Section */}
      <section id="simulacao" className="py-24 px-4">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Simule sua economia</h2>
            <p className="text-lg text-muted-foreground">Receba uma simulação personalizada de forma rápida e prática.</p>
          </div>

          <Card className="p-8 md:p-12 glass dark:glass-dark shadow-soft glow">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <Label htmlFor="name" className="text-base font-semibold mb-2 block">Nome completo</Label>
                <Input
                  id="name"
                  name="name"
                  placeholder="Seu nome"
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                  className="bg-input border-border rounded-lg h-12 text-base"
                />
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="phone" className="text-base font-semibold mb-2 block">Telefone</Label>
                  <Input
                    id="phone"
                    name="phone"
                    placeholder="(85) 99999-9999"
                    value={formData.phone}
                    onChange={handleInputChange}
                    required
                    className="bg-input border-border rounded-lg h-12 text-base"
                  />
                </div>
                <div>
                  <Label htmlFor="email" className="text-base font-semibold mb-2 block">Email</Label>
                  <Input
                    id="email"
                    name="email"
                    placeholder="voce@empresa.com"
                    type="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    className="bg-input border-border rounded-lg h-12 text-base"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="energyBillAmount" className="text-base font-semibold mb-2 block">Valor da conta de energia</Label>
                <Input
                  id="energyBillAmount"
                  name="energyBillAmount"
                  placeholder="Ex.: R$ 8.500,00"
                  value={formData.energyBillAmount}
                  onChange={handleInputChange}
                  required
                  className="bg-input border-border rounded-lg h-12 text-base"
                />
              </div>

              <Button 
                type="submit" 
                disabled={isSubmitting}
                className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-bold h-12 text-base rounded-lg shadow-soft hover:shadow-lg transition-smooth"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Enviando...
                  </>
                ) : (
                  <>
                    Quero economizar
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </>
                )}
              </Button>

              <p className="text-xs text-muted-foreground text-center">
                ✓ Seus dados são seguros e não serão compartilhados
              </p>
            </form>
          </Card>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-24 px-4 bg-card/50">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Perguntas frequentes</h2>
            <p className="text-lg text-muted-foreground">Tire suas dúvidas sobre a Recover Energy</p>
          </div>

          <div className="space-y-4">
            {[
              {
                q: "Preciso fazer obras ou investimento inicial?",
                a: "Não! A Recover Energy funciona sem obras, sem investimento inicial e sem burocracia. Você começa a economizar imediatamente após a implementação."
              },
              {
                q: "Quanto tempo leva para implementar?",
                a: "O processo é rápido. Após a aprovação, a implementação leva em média 2-4 semanas, dependendo da complexidade do seu contrato."
              },
              {
                q: "Qual é a economia média?",
                a: "A economia média é de 30%, mas pode variar de 20% a 40% dependendo do seu perfil de consumo e das opções disponíveis no mercado."
              },
              {
                q: "E se não gostar do resultado?",
                a: "Você tem total segurança. Analisamos todas as opções do mercado para garantir a melhor solução. Se não ficar satisfeito, podemos revisar a estratégia."
              },
            ].map((faq, idx) => (
                  <Card className="p-6 glass dark:glass-dark shadow-soft hover:shadow-lg transition-smooth cursor-pointer group">
                <div className="flex items-start justify-between">
                  <h3 className="text-lg font-bold group-hover:text-accent transition-smooth">{faq.q}</h3>
                  <ChevronDown className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-1" />
                </div>
                <p className="text-muted-foreground mt-4">{faq.a}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Final Section */}
      <section className="py-24 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">Pronto para economizar?</h2>
          <p className="text-lg text-muted-foreground mb-8">
            Junte-se a mais de 2000 empresas que já estão economizando com a Recover Energy.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg"
                className="bg-accent hover:bg-accent/90 text-accent-foreground font-bold rounded-lg shadow-soft hover:shadow-lg transition-smooth btn-hover"
              onClick={() => {
                const element = document.getElementById('simulacao');
                element?.scrollIntoView({ behavior: 'smooth' });
              }}
            >
              Simular agora
            </Button>
            <Button 
              size="lg"
              variant="outline"
              className="border-2 border-accent text-accent hover:bg-accent/10 font-bold rounded-lg transition-smooth"
              onClick={() => window.open('https://wa.me/5585981809403?text=Olá, gostaria de saber mais sobre a Recover Energy', '_blank')}
            >
              Falar com especialista
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 bg-card/50 border-t border-border">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Zap className="w-5 h-5 text-accent" />
                <span className="font-bold">Recover Energy</span>
              </div>
              <p className="text-sm text-muted-foreground">Economia de energia inteligente para seu negócio.</p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Produto</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#como-funciona" className="hover:text-accent transition-smooth">Como funciona</a></li>
                <li><a href="#beneficios" className="hover:text-accent transition-smooth">Benefícios</a></li>
                <li><a href="#testemunhos" className="hover:text-accent transition-smooth">Testemunhos</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Contato</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-center gap-2"><Phone className="w-4 h-4" /> (85) 98180-9403</li>
                <li className="flex items-center gap-2"><Mail className="w-4 h-4" /> contato@recoverenergy.com.br</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Redes Sociais</h4>
              <div className="flex gap-4">
                <a href="https://www.instagram.com/recoverenergia?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-accent transition-smooth">Instagram</a>
              </div>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2026 Recover Energy. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
