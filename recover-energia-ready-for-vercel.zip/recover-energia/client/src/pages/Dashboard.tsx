import { useEmailAuth } from "@/_core/hooks/useEmailAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Loader2, LogOut, Edit2, Users, TrendingUp, CheckCircle, Phone, Mail, DollarSign, Calendar, Search, Filter, Download, Eye } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

export default function Dashboard() {
  const { user, logout } = useEmailAuth({ redirectOnUnauthenticated: true });
  const [, setLocation] = useLocation();
  const [statusFilter, setStatusFilter] = useState<string>("todos");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedLead, setSelectedLead] = useState<any>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [editStatus, setEditStatus] = useState("");
  const [editNotes, setEditNotes] = useState("");

  const { data: leadsData, isLoading } = trpc.leads.list.useQuery(undefined, {
    enabled: user?.role === "admin",
  });

  const updateLeadMutation = trpc.leads.update.useMutation({
    onSuccess: () => {
      toast.success("Lead atualizado com sucesso");
      setIsEditDialogOpen(false);
      setSelectedLead(null);
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao atualizar lead");
    },
  });

  const handleEditLead = (lead: any) => {
    setSelectedLead(lead);
    setEditStatus(lead.status);
    setEditNotes(lead.notes || "");
    setIsEditDialogOpen(true);
  };

  const handleViewLead = (lead: any) => {
    setSelectedLead(lead);
    setIsViewDialogOpen(true);
  };

  const handleSaveEdit = async () => {
    if (!selectedLead) return;
    await updateLeadMutation.mutateAsync({
      id: selectedLead.id,
      status: editStatus as any,
      notes: editNotes || null,
    });
  };

  // Verificar se é admin
  if (!user || user.role !== "admin") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="p-8 text-center max-w-md">
          <p className="text-xl font-semibold mb-4">Acesso restrito ao administrador</p>
          <p className="text-muted-foreground mb-6">Você não tem permissão para acessar o dashboard.</p>
          <Button onClick={() => setLocation("/")} className="w-full">
            Voltar para Home
          </Button>
        </Card>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-accent" />
      </div>
    );
  }

  const allLeads = leadsData?.leads || [];
  const totals = leadsData?.totals || { total: 0, novo: 0, contatado: 0, qualificado: 0, convertido: 0 };

  // Filtrar leads por status e busca
  let filteredLeads = statusFilter === "todos" 
    ? allLeads 
    : allLeads.filter(lead => lead.status === statusFilter);

  if (searchTerm) {
    filteredLeads = filteredLeads.filter(lead =>
      lead.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.phone.includes(searchTerm)
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "novo":
        return { bg: "bg-blue-100 dark:bg-blue-900/30", text: "text-blue-700 dark:text-blue-300", border: "border-blue-200 dark:border-blue-800" };
      case "contatado":
        return { bg: "bg-yellow-100 dark:bg-yellow-900/30", text: "text-yellow-700 dark:text-yellow-300", border: "border-yellow-200 dark:border-yellow-800" };
      case "qualificado":
        return { bg: "bg-purple-100 dark:bg-purple-900/30", text: "text-purple-700 dark:text-purple-300", border: "border-purple-200 dark:border-purple-800" };
      case "convertido":
        return { bg: "bg-green-100 dark:bg-green-900/30", text: "text-green-700 dark:text-green-300", border: "border-green-200 dark:border-green-800" };
      default:
        return { bg: "bg-gray-100 dark:bg-gray-900/30", text: "text-gray-700 dark:text-gray-300", border: "border-gray-200 dark:border-gray-800" };
    }
  };

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      novo: "Novo",
      contatado: "Contatado",
      qualificado: "Qualificado",
      convertido: "Convertido",
    };
    return labels[status] || status;
  };

  const conversionRate = totals.total > 0 ? Math.round((totals.convertido / totals.total) * 100) : 0;

  // Dados para gráficos
  const statusChartData = [
    { name: "Novo", value: totals.novo, fill: "#3b82f6" },
    { name: "Contatado", value: totals.contatado, fill: "#eab308" },
    { name: "Qualificado", value: totals.qualificado, fill: "#a855f7" },
    { name: "Convertido", value: totals.convertido, fill: "#10b981" },
  ];

  const timelineData = [
    { date: "Seg", leads: 12 },
    { date: "Ter", leads: 19 },
    { date: "Qua", leads: 15 },
    { date: "Qui", leads: 25 },
    { date: "Sex", leads: 22 },
    { date: "Sab", leads: 18 },
    { date: "Dom", leads: 14 },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-background/80 backdrop-blur-xl border-b border-border">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold">Dashboard CRM</h1>
            <p className="text-sm text-muted-foreground">Gerencie seus leads e conversões</p>
          </div>
          <Button 
            onClick={logout}
            variant="outline"
            className="gap-2"
          >
            <LogOut className="w-4 h-4" />
            Sair
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Stats Cards */}
        <div className="grid md:grid-cols-5 gap-4 mb-8">
          {[
            { label: "Total de Leads", value: totals.total, icon: Users, color: "blue" },
            { label: "Novos", value: totals.novo, icon: TrendingUp, color: "blue" },
            { label: "Contatados", value: totals.contatado, icon: Phone, color: "yellow" },
            { label: "Qualificados", value: totals.qualificado, icon: CheckCircle, color: "purple" },
            { label: "Convertidos", value: totals.convertido, icon: CheckCircle, color: "green" },
          ].map((stat, idx) => {
            const Icon = stat.icon;
            const colorMap: Record<string, string> = {
              blue: "from-blue-600 to-blue-400",
              yellow: "from-yellow-600 to-yellow-400",
              purple: "from-purple-600 to-purple-400",
              green: "from-green-600 to-green-400",
            };
            return (
              <Card key={idx} className="p-6 border-border/50 shadow-soft hover:shadow-lg transition-smooth">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">{stat.label}</p>
                    <p className="text-3xl font-bold">{stat.value}</p>
                  </div>
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${colorMap[stat.color]} flex items-center justify-center`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                </div>
              </Card>
            );
          })}
        </div>

        {/* Conversion Rate */}
        <div className="mb-8">
          <Card className="p-6 border-border/50 shadow-soft">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-2">Taxa de Conversão</p>
                <p className="text-4xl font-bold gradient-text">{conversionRate}%</p>
              </div>
              <div className="w-24 h-24">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={statusChartData}
                      cx="50%"
                      cy="50%"
                      innerRadius={30}
                      outerRadius={50}
                      paddingAngle={2}
                      dataKey="value"
                    >
                      {statusChartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid md:grid-cols-2 gap-8 mb-8">
          {/* Status Distribution */}
          <Card className="p-6 border-border/50 shadow-soft">
            <h3 className="text-lg font-bold mb-6">Distribuição por Status</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={statusChartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.1)" />
                <XAxis dataKey="name" stroke="rgba(0,0,0,0.5)" />
                <YAxis stroke="rgba(0,0,0,0.5)" />
                <Tooltip />
                <Bar dataKey="value" fill="#00d084" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>

          {/* Timeline */}
          <Card className="p-6 border-border/50 shadow-soft">
            <h3 className="text-lg font-bold mb-6">Leads por Dia</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={timelineData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.1)" />
                <XAxis dataKey="date" stroke="rgba(0,0,0,0.5)" />
                <YAxis stroke="rgba(0,0,0,0.5)" />
                <Tooltip />
                <Line type="monotone" dataKey="leads" stroke="#0066ff" strokeWidth={2} dot={{ fill: "#0066ff", r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </Card>
        </div>

        {/* Leads Table */}
        <Card className="border-border/50 shadow-soft overflow-hidden">
          <div className="p-6 border-b border-border">
            <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar por nome, email ou telefone..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-input border-border rounded-lg"
                />
              </div>
              <div className="flex gap-2">
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-40 bg-input border-border rounded-lg">
                    <Filter className="w-4 h-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos os status</SelectItem>
                    <SelectItem value="novo">Novo</SelectItem>
                    <SelectItem value="contatado">Contatado</SelectItem>
                    <SelectItem value="qualificado">Qualificado</SelectItem>
                    <SelectItem value="convertido">Convertido</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" className="gap-2">
                  <Download className="w-4 h-4" />
                  Exportar
                </Button>
              </div>
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-card/50 border-b border-border">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-semibold">Nome</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold">Email</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold">Telefone</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold">Valor</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold">Status</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold">Data</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold">Ações</th>
                </tr>
              </thead>
              <tbody>
                {filteredLeads.length > 0 ? (
                  filteredLeads.map((lead: any) => {
                    const statusColor = getStatusColor(lead.status);
                    return (
                      <tr key={lead.id} className="border-b border-border hover:bg-card/50 transition-smooth">
                        <td className="px-6 py-4 font-medium">{lead.name}</td>
                        <td className="px-6 py-4 text-sm text-muted-foreground">{lead.email}</td>
                        <td className="px-6 py-4 text-sm">{lead.phone}</td>
                        <td className="px-6 py-4 font-medium flex items-center gap-1">
                          <DollarSign className="w-4 h-4 text-muted-foreground" />
                          {lead.energyBillAmount}
                        </td>
                        <td className="px-6 py-4">
                          <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium border ${statusColor.bg} ${statusColor.text} ${statusColor.border}`}>
                            {getStatusLabel(lead.status)}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm text-muted-foreground">
                          {new Date(lead.createdAt).toLocaleDateString('pt-BR')}
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex gap-2">
                            <Dialog open={isViewDialogOpen && selectedLead?.id === lead.id} onOpenChange={setIsViewDialogOpen}>
                              <DialogTrigger asChild>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleViewLead(lead)}
                                  className="gap-1"
                                >
                                  <Eye className="w-4 h-4" />
                                  Ver
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="max-w-md">
                                <DialogHeader>
                                  <DialogTitle>Detalhes do Lead</DialogTitle>
                                </DialogHeader>
                                {selectedLead && (
                                  <div className="space-y-4">
                                    <div>
                                      <p className="text-sm text-muted-foreground">Nome</p>
                                      <p className="font-semibold">{selectedLead.name}</p>
                                    </div>
                                    <div>
                                      <p className="text-sm text-muted-foreground">Email</p>
                                      <p className="font-semibold">{selectedLead.email}</p>
                                    </div>
                                    <div>
                                      <p className="text-sm text-muted-foreground">Telefone</p>
                                      <p className="font-semibold">{selectedLead.phone}</p>
                                    </div>
                                    <div>
                                      <p className="text-sm text-muted-foreground">Valor da Conta</p>
                                      <p className="font-semibold">{selectedLead.energyBillAmount}</p>
                                    </div>
                                    <div>
                                      <p className="text-sm text-muted-foreground">Status</p>
                                      <p className="font-semibold">{getStatusLabel(selectedLead.status)}</p>
                                    </div>
                                    <div>
                                      <p className="text-sm text-muted-foreground">Data de Captura</p>
                                      <p className="font-semibold">{new Date(selectedLead.createdAt).toLocaleDateString('pt-BR')}</p>
                                    </div>
                                    {selectedLead.notes && (
                                      <div>
                                        <p className="text-sm text-muted-foreground">Notas</p>
                                        <p className="font-semibold">{selectedLead.notes}</p>
                                      </div>
                                    )}
                                  </div>
                                )}
                              </DialogContent>
                            </Dialog>

                            <Dialog open={isEditDialogOpen && selectedLead?.id === lead.id} onOpenChange={setIsEditDialogOpen}>
                              <DialogTrigger asChild>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleEditLead(lead)}
                                  className="gap-1"
                                >
                                  <Edit2 className="w-4 h-4" />
                                  Editar
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="max-w-md">
                                <DialogHeader>
                                  <DialogTitle>Editar Lead</DialogTitle>
                                </DialogHeader>
                                <div className="space-y-4">
                                  <div>
                                    <Label htmlFor="status">Status</Label>
                                    <Select value={editStatus} onValueChange={setEditStatus}>
                                      <SelectTrigger className="bg-input border-border rounded-lg">
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="novo">Novo</SelectItem>
                                        <SelectItem value="contatado">Contatado</SelectItem>
                                        <SelectItem value="qualificado">Qualificado</SelectItem>
                                        <SelectItem value="convertido">Convertido</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </div>
                                  <div>
                                    <Label htmlFor="notes">Notas</Label>
                                    <Textarea
                                      id="notes"
                                      placeholder="Adicione notas sobre este lead..."
                                      value={editNotes}
                                      onChange={(e) => setEditNotes(e.target.value)}
                                      className="bg-input border-border rounded-lg"
                                    />
                                  </div>
                                  <Button
                                    onClick={handleSaveEdit}
                                    disabled={updateLeadMutation.isPending}
                                    className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
                                  >
                                    {updateLeadMutation.isPending ? (
                                      <>
                                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                        Salvando...
                                      </>
                                    ) : (
                                      "Salvar Alterações"
                                    )}
                                  </Button>
                                </div>
                              </DialogContent>
                            </Dialog>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={7} className="px-6 py-8 text-center text-muted-foreground">
                      Nenhum lead encontrado
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
}
