import { Button } from "@/components/ui/button";
import { CheckCircle, Phone, Mail } from "lucide-react";
import { useLocation } from "wouter";

export default function ThankYou() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 text-white flex items-center justify-center px-4">
      <div className="max-w-2xl w-full text-center">
        <div className="mb-8 flex justify-center">
          <div className="relative">
            <div className="absolute inset-0 bg-green-400/20 rounded-full blur-2xl"></div>
            <CheckCircle className="w-24 h-24 text-green-400 relative" />
          </div>
        </div>

        <h1 className="text-5xl font-bold mb-4">Obrigado!</h1>
        <p className="text-2xl text-slate-300 mb-8">
          Recebemos seus dados com sucesso.
        </p>

        <div className="bg-slate-800 border border-slate-700 rounded-lg p-8 mb-8">
          <p className="text-slate-300 mb-6">
            Nosso time de especialistas está analisando suas informações. Em breve, você receberá:
          </p>
          <ul className="space-y-4 text-left mb-6">
            <li className="flex items-center gap-3">
              <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
              <span>Uma análise detalhada da sua conta de energia</span>
            </li>
            <li className="flex items-center gap-3">
              <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
              <span>Proposta personalizada de economia</span>
            </li>
            <li className="flex items-center gap-3">
              <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
              <span>Cronograma de implementação</span>
            </li>
          </ul>
        </div>

        <div className="bg-slate-800 border border-yellow-400/20 rounded-lg p-6 mb-8">
          <h2 className="font-bold text-lg mb-4">Próximos Passos</h2>
          <p className="text-slate-300 mb-6">
            Você pode nos contatar diretamente para acelerar o processo:
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="https://wa.me/5585981809403"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-6 rounded-lg transition"
            >
              <Phone className="w-5 h-5" />
              WhatsApp
            </a>
            <a
              href="mailto:contato@recoverenergy.com"
              className="flex items-center justify-center gap-2 bg-slate-700 hover:bg-slate-600 text-white font-bold py-3 px-6 rounded-lg transition"
            >
              <Mail className="w-5 h-5" />
              Email
            </a>
          </div>
        </div>

        <Button
          onClick={() => setLocation("/")}
          variant="outline"
          size="lg"
          className="border-yellow-400 text-yellow-400 hover:bg-yellow-400/10"
        >
          Voltar para Home
        </Button>
      </div>
    </div>
  );
}
