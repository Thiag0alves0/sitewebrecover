import bcryptjs from "bcryptjs";
import { drizzle } from "drizzle-orm/mysql2";
import { users } from "../drizzle/schema";

const DATABASE_URL = process.env.DATABASE_URL;

async function initAdmin() {
  if (!DATABASE_URL) {
    console.error("DATABASE_URL não está configurada");
    process.exit(1);
  }

  try {
    const db = drizzle(DATABASE_URL);

    const email = "recoverenergiasite@gmail.com";
    const password = "recover0287";
    const name = "Recover Energy Admin";

    // Verificar se o usuário já existe
    const existingUser = await db.select().from(users).where(
      (u) => u.email === email
    );

    if (existingUser.length > 0) {
      console.log("Usuário admin já existe");
      process.exit(0);
    }

    // Hash da senha
    const salt = await bcryptjs.genSalt(10);
    const hashedPassword = await bcryptjs.hash(password, salt);

    // Criar usuário admin
    await db.insert(users).values({
      email,
      password: hashedPassword,
      name,
      role: "admin",
      loginMethod: "email",
    });

    console.log("✅ Usuário admin criado com sucesso!");
    console.log(`Email: ${email}`);
    console.log(`Senha: ${password}`);
  } catch (error) {
    console.error("Erro ao criar usuário admin:", error);
    process.exit(1);
  }
}

initAdmin();
