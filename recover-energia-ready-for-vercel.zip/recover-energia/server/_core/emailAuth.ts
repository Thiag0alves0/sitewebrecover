import bcryptjs from "bcryptjs";
import type { Request, Response } from "express";
import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import * as db from "../db";
import { getSessionCookieOptions } from "./cookies";
import { ENV } from "./env";
import { SignJWT, jwtVerify } from "jose";

export type SessionPayload = {
  userId: number;
  email: string;
  role: string;
};

class EmailAuthService {
  private getSessionSecret() {
    const secret = ENV.cookieSecret;
    return new TextEncoder().encode(secret);
  }

  async hashPassword(password: string): Promise<string> {
    const salt = await bcryptjs.genSalt(10);
    return bcryptjs.hash(password, salt);
  }

  async comparePassword(password: string, hash: string): Promise<boolean> {
    return bcryptjs.compare(password, hash);
  }

  async createSessionToken(
    userId: number,
    email: string,
    role: string,
    options: { expiresInMs?: number } = {}
  ): Promise<string> {
    const issuedAt = Date.now();
    const expiresInMs = options.expiresInMs ?? ONE_YEAR_MS;
    const expirationSeconds = Math.floor((issuedAt + expiresInMs) / 1000);
    const secretKey = this.getSessionSecret();

    return new SignJWT({
      userId,
      email,
      role,
    })
      .setProtectedHeader({ alg: "HS256", typ: "JWT" })
      .setExpirationTime(expirationSeconds)
      .sign(secretKey);
  }

  async verifySession(
    cookieValue: string | undefined | null
  ): Promise<SessionPayload | null> {
    if (!cookieValue) {
      console.warn("[Auth] Missing session cookie");
      return null;
    }

    try {
      const secretKey = this.getSessionSecret();
      const { payload } = await jwtVerify(cookieValue, secretKey, {
        algorithms: ["HS256"],
      });
      const { userId, email, role } = payload as Record<string, unknown>;

      if (
        typeof userId !== "number" ||
        typeof email !== "string" ||
        typeof role !== "string"
      ) {
        console.warn("[Auth] Session payload missing required fields");
        return null;
      }

      return {
        userId,
        email,
        role,
      };
    } catch (error) {
      console.warn("[Auth] Session verification failed", String(error));
      return null;
    }
  }

  async login(email: string, password: string) {
    const user = await db.getUserByEmail(email);

    if (!user || !user.password) {
      throw new Error("Email ou senha inválidos");
    }

    const isPasswordValid = await this.comparePassword(password, user.password);

    if (!isPasswordValid) {
      throw new Error("Email ou senha inválidos");
    }

    const sessionToken = await this.createSessionToken(user.id, user.email || "", user.role, {
      expiresInMs: ONE_YEAR_MS,
    });

    // Update last signed in
    await db.updateUserLastSignedIn(user.id);

    return {
      sessionToken,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
      },
    };
  }

  async registerAdmin(email: string, password: string, name: string) {
    // Check if user already exists
    const existingUser = await db.getUserByEmail(email);
    if (existingUser) {
      throw new Error("Email já cadastrado");
    }

    const hashedPassword = await this.hashPassword(password);

    const user = await db.createUser({
      email,
      password: hashedPassword,
      name,
      role: "admin",
      loginMethod: "email",
    });

    const sessionToken = await this.createSessionToken(user.id, user.email || "", user.role, {
      expiresInMs: ONE_YEAR_MS,
    });

    return {
      sessionToken,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
      },
    };
  }
}

export const emailAuthService = new EmailAuthService();

export function registerEmailAuthRoutes(app: any) {
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        res.status(400).json({ error: "Email e senha são obrigatórios" });
        return;
      }

      const { sessionToken, user } = await emailAuthService.login(email, password);

      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });

      res.json({
        success: true,
        user,
      });
    } catch (error: any) {
      console.error("[Auth] Login failed", error);
      res.status(401).json({ error: error.message || "Falha ao fazer login" });
    }
  });

  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      const { email, password, name } = req.body;

      if (!email || !password || !name) {
        res.status(400).json({ error: "Email, senha e nome são obrigatórios" });
        return;
      }

      const { sessionToken, user } = await emailAuthService.registerAdmin(email, password, name);

      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });

      res.json({
        success: true,
        user,
      });
    } catch (error: any) {
      console.error("[Auth] Register failed", error);
      res.status(400).json({ error: error.message || "Falha ao registrar" });
    }
  });
}
