/**
 * Utilitário para enviar dados de leads ao Google Sheets via Apps Script
 * Prioridade máxima: garantir que os dados sejam capturados no Google Sheets
 */
import { ENV } from "./_core/env";

interface LeadData {
  name: string;
  phone: string;
  email: string;
  energyBillAmount: string;
  companyName?: string;
  source?: string;
}

const DEFAULT_GOOGLE_SHEETS_URL = "https://script.google.com/macros/s/AKfycbwscuiace56QljVqqgn11qSeASm_1KX5-Wo5mfkdpHQcyq0Pfx34LkTD9vzNcp31aVEqQ/exec";

export async function sendLeadToGoogleSheets(lead: LeadData): Promise<void> {
  const webhookUrl = ENV.googleSheetsWebhookUrl || DEFAULT_GOOGLE_SHEETS_URL;

  try {
    const formData = new URLSearchParams();
    formData.append("name", lead.name);
    formData.append("phone", lead.phone);
    formData.append("email", lead.email);
    formData.append("energyBillAmount", lead.energyBillAmount);
    formData.append("companyName", lead.companyName || "");
    formData.append("source", lead.source || "website");
    formData.append("timestamp", new Date().toISOString());

    const response = await fetch(webhookUrl, {
      method: "POST",
      body: formData,
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
    });

    if (!response.ok) {
      throw new Error(`Google Sheets API returned status ${response.status}`);
    }

    console.log(`[GoogleSheets] Lead enviado com sucesso para o Google Sheets: ${lead.email}`);
  } catch (error) {
    console.error("[GoogleSheets] Falha ao enviar lead para o Google Sheets:", error);
    throw error;
  }
}
