import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { notifyOwner } from "./_core/notification";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";
import { systemRouter } from "./_core/systemRouter";
import { createLead, getAllLeads, updateLeadStatus } from "./db";
import { sendLeadToGoogleSheets } from "./googleSheets";
import { leadStatusEnum } from "../drizzle/schema";

const leadStatusSchema = z.enum(leadStatusEnum);

const createLeadSchema = z.object({
  name: z.string().trim().min(2, "Informe seu nome"),
  phone: z.string().trim().min(8, "Informe um telefone válido"),
  email: z.string().trim().email("Informe um email válido"),
  energyBillAmount: z.string().trim().min(1, "Informe o valor da conta de energia"),
  companyName: z.string().trim().max(160).optional(),
  source: z.string().trim().max(80).optional(),
});

const updateLeadSchema = z.object({
  id: z.number().int().positive(),
  status: leadStatusSchema,
  notes: z.string().trim().max(1200).nullable().optional(),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),
  leads: router({
    create: publicProcedure.input(createLeadSchema).mutation(async ({ input }) => {
      // Envia os dados para o Google Sheets imediatamente (prioridade máxima)
      await sendLeadToGoogleSheets({
        name: input.name,
        phone: input.phone,
        email: input.email,
        energyBillAmount: input.energyBillAmount,
        companyName: input.companyName,
        source: input.source,
      }).catch(error => {
        console.warn("[GoogleSheets] Erro ao enviar lead para o Google Sheets:", error);
      });

      // Tenta salvar no banco de dados (pode não estar disponível em todos os ambientes)
      let createdLead: any = null;
      try {
        createdLead = await createLead(input);
      } catch (dbError) {
        console.warn("[Database] Falha ao salvar lead no banco de dados (dados já enviados ao Google Sheets):", dbError);
      }

      await notifyOwner({
        title: "Novo lead capturado - Recover Energy",
        content: `Nome: ${input.name}\nTelefone: ${input.phone}\nEmail: ${input.email}\nConta de energia: ${input.energyBillAmount}`,
      }).catch(error => {
        console.warn("[Notification] Failed to notify owner about new lead:", error);
      });

      return {
        success: true,
        leadId: createdLead?.id ?? 0,
      } as const;
    }),
    list: adminProcedure.query(async () => {
      const allLeads = await getAllLeads();
      const totals = {
        total: allLeads.length,
        novo: allLeads.filter(lead => lead.status === "novo").length,
        contatado: allLeads.filter(lead => lead.status === "contatado").length,
        qualificado: allLeads.filter(lead => lead.status === "qualificado").length,
        convertido: allLeads.filter(lead => lead.status === "convertido").length,
      };

      return {
        leads: allLeads,
        totals,
      };
    }),
    update: adminProcedure.input(updateLeadSchema).mutation(async ({ input }) => {
      const updatedLead = await updateLeadStatus(input);
      return {
        success: true,
        lead: updatedLead,
      } as const;
    }),
  }),
});

export type AppRouter = typeof appRouter;
