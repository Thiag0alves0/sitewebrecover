import { afterEach, describe, expect, it, vi } from "vitest";

const fetchMock = vi.fn();

vi.stubGlobal("fetch", fetchMock);

describe("sendLeadToGoogleSheets", () => {
  afterEach(() => {
    fetchMock.mockReset();
    delete process.env.GOOGLE_SHEETS_WEBHOOK_URL;
    vi.resetModules();
  });

  it("usa a URL configurada em ambiente quando disponível", async () => {
    process.env.GOOGLE_SHEETS_WEBHOOK_URL = "https://example.com/webhook";
    fetchMock.mockResolvedValue({ ok: true, status: 200 });

    const { sendLeadToGoogleSheets } = await import("./googleSheets");

    await sendLeadToGoogleSheets({
      name: "Teste",
      phone: "85999999999",
      email: "teste@teste.com",
      energyBillAmount: "500",
    });

    expect(fetchMock).toHaveBeenCalledTimes(1);
    const [url, options] = fetchMock.mock.calls[0];
    expect(url).toBe("https://example.com/webhook");
    expect(options.method).toBe("POST");
    expect(options.headers["Content-Type"]).toBe("application/x-www-form-urlencoded");
    expect(String(options.body)).toContain("name=Teste");
    expect(String(options.body)).toContain("email=teste%40teste.com");
  });

  it("mantém o fallback para a URL padrão quando o ambiente não estiver definido", async () => {
    fetchMock.mockResolvedValue({ ok: true, status: 200 });

    const { sendLeadToGoogleSheets } = await import("./googleSheets");

    await sendLeadToGoogleSheets({
      name: "Fallback",
      phone: "85988888888",
      email: "fallback@teste.com",
      energyBillAmount: "700",
    });

    const [url] = fetchMock.mock.calls[0];
    expect(url).toBe(
      "https://script.google.com/macros/s/AKfycbwscuiace56QljVqqgn11qSeASm_1KX5-Wo5mfkdpHQcyq0Pfx34LkTD9vzNcp31aVEqQ/exec"
    );
  });
});
